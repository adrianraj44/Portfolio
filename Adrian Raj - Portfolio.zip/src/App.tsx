import { useState, useEffect } from 'react'
import headshot from './imports/1759878695729.jpg'
import utCampus from './imports/attachment_e406e072.png'
import resumePdf from './imports/Adrian_Raj_-_Resume-2.pdf'
import coverLetterPdf from './imports/Adrian_Raj_-_Cover_Letter-1.pdf'
const ar05Pdf = '/ar05.pdf'
const ar11Pdf = '/ar11.pdf'

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Experience', href: '#experience' },
  { label: 'Leadership', href: '#leadership' },
  { label: 'Volunteering', href: '#volunteering' },
  { label: 'Projects', href: '#projects' },
  { label: 'Skills', href: '#skills' },
  { label: 'Contact', href: '#contact' },
]

const EXPERIENCE = [
  {
    company: 'Austin Parks & Recreation',
    role: 'Recreation Programs Instructor',
    location: 'Austin, TX',
    date: 'Oct 2025 – Present',
    bullets: [
      'Managing attendance records and documentation for students to support accurate reports and program continuity',
      'Configuring facility equipment across multiple recreation centers to maintain event and emergency readiness',
      'Coaching 6U–12U in soccer and basketball by adapting instruction to each group\'s developmental level',
      'Implementing a recreational curriculum for 30+ K–5 students to ensure consistent program quality',
    ],
    tag: 'Instruction',
    color: '#5c3d1e',
  },
  {
    company: 'Red Canyon Engineering & Software',
    role: 'Core Flight System (cFS) Intern',
    location: 'Denver, CO',
    date: 'Jun 2026 – Aug 2026',
    bullets: [
      'Developed C/C++ applications within NASA\'s cFS, adhering to NASA coding standards and RTOS constraints',
      'Authored and executed V&V procedures for flight software, ensuring compliance with NASA safety standards',
      'Collaborated with a senior engineer to integrate and test cFS applications across simulated mission scenarios',
    ],
    tag: 'Engineering',
    color: '#BF5700',
  },
  {
    company: 'Austin Convention Center',
    role: 'Cashier I',
    location: 'Austin, TX',
    date: 'Feb 2025 – Jun 2025',
    bullets: [
      'Audited checkout procedures to identify gaps and reported findings to management to improve cashier workflow',
      'Applied POS protocols and safety standards across all transactions to maintain a compliant guest experience',
      'Reconciled $500–$1,000 cash drawers at the beginning and end of shifts to maintain financial accountability',
      'Processed various payment transactions under high-volume conditions to deliver quality customer service',
    ],
    tag: 'Operations',
    color: '#7a6040',
  },
  {
    company: 'Whataburger',
    role: 'Certified Restaurant Trainer',
    location: 'Cedar Park, TX',
    date: 'May 2024 – Sep 2024',
    bullets: [
      'Delivered onboarding training for new hires on food safety, customer service, and operations to accelerate efficiency',
      'Served as liaison between crew and management during high-volume shifts to resolve issues and reduce friction',
      'Monitored performance via quality checks during 600–800 customers/day shifts to sustain service consistency',
      'Identified food preparation inefficiencies and implemented changes to reduce errors during peak periods',
    ],
    tag: 'Training',
    color: '#a89260',
  },
]

const LEADERSHIP = [
  {
    org: 'Student Government (UTSG)',
    location: 'Austin, TX',
    positions: [
      {
        role: 'Engineering Representative',
        date: 'Apr 2025 – Apr 2026',
        bullets: [
          'Represented 8,500+ Cockrell School of Engineering students on a variety of topics and issues on and off campus',
          'Passed A.R. 05, promoting mental health resources to UT Austin engineering students via online newsletters',
          'Passed A.R. 11, creating food satellites at the Cockrell (Engineering) and McCombs (Business) schools',
          'Served on the Student Affairs Committee, overseeing legislation related to student life at UT Austin',
        ],
      },
      {
        role: 'Disabilities Inclusion Agency (DIA) Member',
        date: 'Sep 2024 – Apr 2025',
        bullets: [
          'Advocated for students with disabilities through disability-related events and professor roundtables',
          'Helped pass A.R. 17, renovating all campus bathrooms up to TAS/ADA standards at UT Austin',
          'Served on the Legislative Committee, working with the General Assembly to pass legislation',
        ],
      },
    ],
  },
  {
    org: 'American Institute of Aeronautics and Astronautics (AIAA)',
    location: 'Austin, TX',
    positions: [
      {
        role: 'Webmaster',
        date: 'Apr 2025 – Apr 2026',
        bullets: [
          'Designed and maintained the UI/UX for UT Austin AIAA\'s new website, supporting organizational awareness',
          'Co-coordinated semesterly chapter socials with the Social Media Chair to support membership recruitment',
          'Implemented SEO practices and tracked site analytics to measure engagement and make improvements',
        ],
      },
      {
        role: 'Freshman Representative',
        date: 'Sep 2024 – Apr 2025',
        bullets: [
          'Represented 120+ first-year Aerospace Engineering students in officer meetings to advocate for cohort needs',
          'Recruited aerospace-interested students into AIAA and co-developed first-year community-building events',
          'Assisted with organization onboarding sessions for incoming aerospace students to integrate into AIAA',
        ],
      },
    ],
  },
]

const VOLUNTEERING = [
  {
    org: 'Autodesk',
    location: 'Austin, TX',
    positions: [
      {
        role: 'Design & Make Ambassador',
        date: 'Jan 2026 – Dec 2026',
        bullets: [
          'Collaborated with Autodesk ambassadors to plan and execute CAD-based events at UT Austin to grow awareness',
          'Organized workshops and lectures to teach CAD rudiments to students and support hands-on design education',
          'Produced social media content in partnership with Autodesk to expand its usage among UT undergraduates',
        ],
      },
    ],
  },
  {
    org: 'NASA L\'SPACE Program',
    location: 'Tempe, AZ',
    positions: [
      {
        role: 'NASA Lucy Mission Ambassador',
        date: 'Sep 2025 – Apr 2026',
        bullets: [
          'Completed NASA-certified training on the Lucy Mission and planetary science to prepare for presentations',
          'Coordinated 3+ annual public venue events to communicate the significance of the NASA Lucy Mission',
          'Produced social media content to promote the L\'SPACE Program\'s workforce development programs',
        ],
      },
      {
        role: 'Mission Concept Academy (MCA) Command & Data Handling (CDH) Engineer',
        date: 'May 2025 – Aug 2025',
        bullets: [
          'Led CDH trade studies and the Software Architecture Flowchart for a 20-person NASA-guided Mars mission',
          'Contributed to 4 NASA review documents (MCR, SRR, MDR, PDR) and earned an 8/10 PDR CDH rating',
          'Utilized Siemens NX and JMARS to support trajectory calculations for a simulated Mars spacecraft landing',
        ],
      },
      {
        role: 'NASA Proposal Writing and Evaluation Experience (NPWEE) Engineer',
        date: 'Jan 2025 – Apr 2025',
        bullets: [
          'Co-developed a Recyclable Filament CAD prototype across multiple Siemens NX iterations with a 10-person team',
          'Used NASA systems engineering principles to evaluate material reusability for space manufacturing applications',
          'Authored a 7-page NASA proposal detailing the design process and reviewed 3 competing team submissions',
        ],
      },
    ],
  },
  {
    org: 'Student Engineers Educating Kids (SEEK)',
    location: 'Austin, TX',
    positions: [
      {
        role: 'Student Mentor',
        date: 'Aug 2024 – Dec 2025',
        bullets: [
          'Delivered hands-on STEM lessons to K–5 students at Austin ISD Title I schools for early engineering interest',
          'Facilitated inquiry-based activities for underserved youth to develop STEM curiosity and analytical skills',
          'Partnered with Communities in Schools (CIS) to extend STEM access to low-income students in Austin',
        ],
      },
    ],
  },
]

const SKILLS_PROGRAMMING = ['Python', 'C/C++', 'HTML', 'CSS', 'JavaScript']
const SKILLS_CAD = ['Siemens NX', 'SOLIDWORKS', 'JMARS', 'Autodesk Inventor', 'PTC Onshape']
const SKILLS_WEB = ['UI/UX Design', 'Web Development', 'Figma', 'Microsoft Office']
const SKILLS_SOFT = ['Leadership', 'Communication', 'Customer Service', 'Teamwork', 'Public Relations', 'Presentations', 'Youth Mentoring', 'Recreational Programming', 'Social Media', 'Stakeholder Advocacy', 'Networking', 'Public Policy', 'Legislation', 'Student Affairs', 'Financial Transactions']
const SKILLS_LANG = ['English (Native)', 'Spanish (Fluent)', 'Adult & Pediatric First Aid/CPR/AED (Certified)']

export default function App() {
  const [scrolled, setScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40)
      const sections = NAV_LINKS.map(l => l.href.slice(1))
      for (const id of [...sections].reverse()) {
        const el = document.getElementById(id)
        if (el && el.getBoundingClientRect().top <= 120) {
          setActiveSection(id)
          break
        }
      }
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div style={{ fontFamily: 'Inter, system-ui, sans-serif' }}>
      {/* NAV */}
      <nav
        style={{
          position: 'fixed',
          top: 0, left: 0, right: 0,
          zIndex: 50,
          transition: 'all 0.3s ease',
          background: scrolled ? 'rgba(255,255,255,0.97)' : 'transparent',
          backdropFilter: scrolled ? 'blur(10px)' : 'none',
          borderBottom: scrolled ? '1px solid #e8e0d4' : 'none',
          boxShadow: scrolled ? '0 1px 16px rgba(191,87,0,0.06)' : 'none',
        }}
      >
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
          <a href="#" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 18, fontWeight: 800, color: '#BF5700', letterSpacing: '-0.5px' }}>Adrian Raj</span>
          </a>

          <div style={{ display: 'flex', gap: 2, alignItems: 'center' }} className="hidden-mobile">
            {NAV_LINKS.map(link => (
              <a
                key={link.href}
                href={link.href}
                style={{
                  padding: '6px 12px',
                  fontSize: 13,
                  fontWeight: 500,
                  textDecoration: 'none',
                  color: activeSection === link.href.slice(1) ? '#BF5700' : '#1a1209',
                  borderRadius: 4,
                  transition: 'color 0.2s',
                }}
                onMouseEnter={e => { if (activeSection !== link.href.slice(1)) (e.target as HTMLElement).style.color = '#BF5700' }}
                onMouseLeave={e => { if (activeSection !== link.href.slice(1)) (e.target as HTMLElement).style.color = '#1a1209' }}
              >
                {link.label}
              </a>
            ))}
          </div>

          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 8, display: 'none' }}
            className="show-mobile"
            aria-label="Menu"
          >
            <div style={{ width: 22, height: 2, background: '#1a1209', marginBottom: 5, transition: '0.2s', transform: menuOpen ? 'rotate(45deg) translate(5px,5px)' : 'none' }} />
            <div style={{ width: 22, height: 2, background: '#1a1209', marginBottom: 5, opacity: menuOpen ? 0 : 1 }} />
            <div style={{ width: 22, height: 2, background: '#1a1209', transition: '0.2s', transform: menuOpen ? 'rotate(-45deg) translate(5px,-5px)' : 'none' }} />
          </button>
        </div>

        {menuOpen && (
          <div style={{ background: '#fff', borderTop: '1px solid #e8e0d4', padding: '16px 24px 24px' }}>
            {NAV_LINKS.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                style={{ display: 'block', padding: '12px 0', fontSize: 15, fontWeight: 500, color: '#1a1209', textDecoration: 'none', borderBottom: '1px solid #f0ebe3' }}
              >
                {link.label}
              </a>
            ))}
          </div>
        )}
      </nav>

      <style>{`
        @media (max-width: 900px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
          .hero-title { font-size: 48px !important; }
          .hero-grid { grid-template-columns: 1fr !important; }
          .about-grid { grid-template-columns: 1fr !important; }
          .section-inner { padding: 72px 20px !important; }
          .skills-grid { grid-template-columns: 1fr !important; }
          .vol-grid { grid-template-columns: 1fr !important; }
          .project-grid { grid-template-columns: 1fr !important; }
        }
        .five-grid { grid-template-columns: repeat(3, 1fr) !important; }
        @media (max-width: 900px) {
          .five-grid { grid-template-columns: 1fr !important; }
        }
        @media (min-width: 901px) {
          .show-mobile { display: none !important; }
        }
      `}</style>

      {/* HERO */}
      <section
        style={{
          minHeight: '100vh',
          background: 'linear-gradient(135deg, #1a1209 0%, #2e1a00 55%, #BF5700 100%)',
          display: 'flex',
          alignItems: 'center',
          position: 'relative',
          overflow: 'hidden',
          paddingTop: 64,
        }}
      >
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(191,87,0,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.04) 0%, transparent 40%)', pointerEvents: 'none' }} />

        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '80px 24px', position: 'relative', zIndex: 1, width: '100%' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }} className="hero-grid">
            <div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(191,87,0,0.25)', border: '1px solid rgba(191,87,0,0.4)', borderRadius: 20, padding: '6px 14px', marginBottom: 28 }}>
                <span style={{ fontSize: 12, color: '#ffb87a', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Hook 'Em · UT Austin · Class of 2028</span>
              </div>

              <h1
                className="hero-title"
                style={{
                  fontFamily: 'Playfair Display, Georgia, serif',
                  fontSize: 68,
                  fontWeight: 900,
                  lineHeight: 1,
                  color: '#ffffff',
                  letterSpacing: '-2px',
                  margin: '0 0 20px',
                }}
              >
                Adrian <span style={{ color: '#BF5700' }}>Raj.</span>
              </h1>

              <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.75)', lineHeight: 1.65, marginBottom: 36, maxWidth: 460 }}>
                PM candidate bridging <strong style={{ color: '#ffb87a' }}>technical fluency</strong> and <strong style={{ color: '#ffb87a' }}>user-focused communication</strong>. Seeking Summer 2027 internships in Product Management.
              </p>

              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                <a
                  href="#experience"
                  style={{ padding: '13px 26px', background: '#BF5700', color: '#fff', fontWeight: 700, fontSize: 14, textDecoration: 'none', borderRadius: 4, letterSpacing: '0.04em', transition: 'background 0.2s' }}
                  onMouseEnter={e => { (e.target as HTMLElement).style.background = '#a34a00' }}
                  onMouseLeave={e => { (e.target as HTMLElement).style.background = '#BF5700' }}
                >
                  View Experience
                </a>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {[
                { num: '8,500+', label: 'Engineering students represented at UTSG' },
                { num: '3+', label: 'NASA Lucy Mission public events coordinated' },
                { num: '2', label: 'Legislative resolutions authored and passed' },
                { num: 'NASA', label: 'Core Flight System (cFS) Intern — Red Canyon Engineering & Software' },
              ].map(stat => (
                <div key={stat.label} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '18px 22px', display: 'flex', alignItems: 'center', gap: 20, backdropFilter: 'blur(4px)' }}>
                  <span style={{ fontFamily: 'Playfair Display, serif', fontSize: 28, fontWeight: 900, color: '#BF5700', minWidth: 64, lineHeight: 1 }}>{stat.num}</span>
                  <span style={{ fontSize: 13.5, color: 'rgba(255,255,255,0.7)', lineHeight: 1.4 }}>{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 80, background: 'linear-gradient(to top, #fff, transparent)' }} />
      </section>

      {/* UT CAMPUS BANNER */}
      <div style={{ position: 'relative', width: '100%', height: 260, overflow: 'hidden' }}>
        <img
          src={utCampus}
          alt="UT Austin campus with the Tower"
          style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 40%', display: 'block' }}
        />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(255,255,255,0.18) 0%, rgba(26,18,9,0.28) 100%)' }} />
      </div>

      {/* ABOUT */}
      <section id="about" style={{ background: '#faf8f4' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', gap: 72, alignItems: 'start' }} className="about-grid">
            {/* Photo + quick facts */}
            <div>
              <img
                src={headshot}
                alt="Adrian Raj"
                style={{
                  width: '100%',
                  maxWidth: 340,
                  aspectRatio: '1/1',
                  objectFit: 'cover',
                  borderRadius: 8,
                  border: '1px solid #e8e0d4',
                  display: 'block',
                  marginBottom: 24,
                  boxShadow: '6px 6px 0px #BF5700',
                }}
              />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {[
                  { label: 'University', value: 'UT Austin' },
                  { label: 'Degree', value: 'BA Rhetoric & Writing' },
                  { label: 'Graduation', value: 'May 2028' },
                  { label: 'Citizenship', value: 'U.S. Citizen' },
                  { label: 'Location', value: 'Austin, TX' },
                  { label: 'Languages', value: 'English, Spanish' },
                ].map(item => (
                  <div key={item.label} style={{ padding: '12px 14px', background: '#fff', borderRadius: 6, border: '1px solid #e8e0d4' }}>
                    <p style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 3 }}>{item.label}</p>
                    <p style={{ fontSize: 13, fontWeight: 600, color: '#1a1209' }}>{item.value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Bio */}
            <div>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>About Me</p>
              <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 42, fontWeight: 800, lineHeight: 1.1, color: '#1a1209', letterSpacing: '-1px', marginBottom: 20 }}>
                Where Engineering<br />Meets Story
              </h2>
              <div style={{ width: 48, height: 4, background: '#BF5700', marginBottom: 28, borderRadius: 2 }} />
              <p style={{ fontSize: 17, lineHeight: 1.8, color: '#3d2e1e', marginBottom: 20 }}>
                I'm a junior at The University of Texas at Austin studying Rhetoric and Writing, with a background that spans NASA flight software, student government, and UI/UX design. I gravitate toward product roles because they sit exactly at the intersection of technical fluency and effective communication.
              </p>
              <p style={{ fontSize: 17, lineHeight: 1.8, color: '#3d2e1e', marginBottom: 28 }}>
                Whether I'm developing C/C++ applications against NASA safety standards, authoring legislation for 8,500+ engineering students, or building a website from scratch — I'm always asking the same question: <em>how does this actually serve the people who depend on it?</em>
              </p>
              <p style={{ fontSize: 17, lineHeight: 1.8, color: '#3d2e1e' }}>
                I'm comfortable moving between code, design, and conversation — and I'm energized by shaping products around real user feedback. I'm actively seeking Summer 2027 PM internships.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* EXPERIENCE */}
      <section id="experience" style={{ background: '#fff' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ marginBottom: 56 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>Work Experience</p>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 48, fontWeight: 800, color: '#1a1209', letterSpacing: '-1.5px' }}>What I've Built</h2>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {EXPERIENCE.map((exp, i) => (
              <ExperienceCard key={i} {...exp} />
            ))}
          </div>
        </div>
      </section>

      {/* LEADERSHIP */}
      <section id="leadership" style={{ background: '#faf8f4' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ marginBottom: 56 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>Leadership</p>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 48, fontWeight: 800, color: '#1a1209', letterSpacing: '-1.5px' }}>Advocacy & Impact</h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 24, marginBottom: 56 }}>
            {LEADERSHIP.map((item, i) => (
              <LeadershipCard key={i} {...item} />
            ))}
          </div>

          {/* Legislation subsection */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
              <div style={{ width: 3, height: 28, background: '#BF5700', borderRadius: 2 }} />
              <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: 26, fontWeight: 800, color: '#1a1209', letterSpacing: '-0.5px' }}>Legislation Authored</h3>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 24 }}>
              <LegislationCard
                number="A.R. 05"
                title="In Support of Promoting Mental Health Resources to Cockrell School of Engineering Students"
                assembly="119th Student Government Assembly · UT Austin"
                summary="Identified that 8,500+ Cockrell engineering students received no mental health newsletters despite other UT colleges having access. Authored and passed a resolution directing the Counseling and Mental Health Center to create weekly engineering-focused mental health newsletters and social media outreach."
                impact="Passed — directed CMHC to create engineering-specific mental health newsletters reaching 8,500+ students"
                pdf={ar05Pdf}
                filename="AR_05_Mental_Health_Resources.pdf"
              />
              <LegislationCard
                number="A.R. 11"
                title="In Support of the Implementation of UT Outpost Satellites at the Cockrell School of Engineering and the McCombs School of Business"
                assembly="119th Student Government Assembly · UT Austin"
                summary="Identified that Cockrell and McCombs students lacked nearby access to UT Outpost food pantry and career closet resources. Co-authored a resolution to establish UT Outpost Satellites in the EER building (Engineering) and CBA building (Business), expanding food and professional attire access campus-wide."
                impact="Passed — created new UT Outpost Satellite locations at Cockrell (EER) and McCombs (CBA)"
                pdf={ar11Pdf}
                filename="AR_11_UT_Outpost_Satellites.pdf"
              />
            </div>
          </div>
        </div>
      </section>

      {/* VOLUNTEERING */}
      <section id="volunteering" style={{ background: '#fff' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ marginBottom: 56 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>Volunteering</p>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 48, fontWeight: 800, color: '#1a1209', letterSpacing: '-1.5px' }}>Giving Back</h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }} className="vol-grid">
            {VOLUNTEERING.map((item, i) => (
              <VolunteerCard key={i} {...item} />
            ))}
          </div>
        </div>
      </section>

      {/* PROJECTS */}
      <section id="projects" style={{ background: '#1a1209' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ marginBottom: 56 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>Projects</p>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 48, fontWeight: 800, color: '#fff', letterSpacing: '-1.5px' }}>What I've Shipped</h2>
          </div>

          <div style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, padding: '40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'center' }} className="project-grid">
            <div>
              <div style={{ display: 'inline-block', background: '#BF5700', color: '#fff', fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: 3, marginBottom: 20 }}>HTML · CSS · JavaScript</div>
              <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: 30, fontWeight: 800, color: '#fff', marginBottom: 16, lineHeight: 1.2 }}>AIAA - UT Austin Website</h3>
              <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.65)', lineHeight: 1.75, marginBottom: 24 }}>
                Designed and launched UT Austin AIAA's chapter website from the ground up — owning UI/UX end-to-end, implementing SEO practices, tracking site analytics, and deploying on HornsLink and Google.
              </p>
              <ul style={{ padding: 0, margin: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 32 }}>
                {[
                  'Full UI/UX design and implementation',
                  'SEO optimization and analytics tracking',
                  'Deployed on HornsLink — UT Austin\'s organizational platform',
                ].map((b, i) => (
                  <li key={i} style={{ fontSize: 14, color: 'rgba(255,255,255,0.6)', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <span style={{ color: '#BF5700', fontWeight: 700, marginTop: 2 }}>→</span>
                    {b}
                  </li>
                ))}
              </ul>
              <a
                href="https://www.aiaautexas.com"
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '12px 24px', background: '#BF5700', color: '#fff', fontWeight: 700, fontSize: 14, textDecoration: 'none', borderRadius: 4, transition: 'background 0.2s' }}
                onMouseEnter={e => { (e.target as HTMLElement).style.background = '#a34a00' }}
                onMouseLeave={e => { (e.target as HTMLElement).style.background = '#BF5700' }}
              >
                Visit Site ↗
              </a>
            </div>
            <div style={{ background: 'rgba(191,87,0,0.12)', border: '1px solid rgba(191,87,0,0.25)', borderRadius: 8, padding: '28px' }}>
              {[
                { label: 'Role', value: 'Designer & Developer' },
                { label: 'Duration', value: 'Apr 2025 – Apr 2026' },
                { label: 'Stack', value: 'HTML, CSS, JavaScript' },
                { label: 'Platform', value: 'HornsLink + Google SEO' },
                { label: 'URL', value: 'aiaautexas.com' },
              ].map(item => (
                <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: 12, marginBottom: 12, borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                  <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{item.label}</span>
                  <span style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', fontWeight: 500 }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" style={{ background: '#faf8f4' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px' }}>
          <div style={{ marginBottom: 56 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#BF5700', marginBottom: 12 }}>Skills & Certifications</p>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 48, fontWeight: 800, color: '#1a1209', letterSpacing: '-1.5px' }}>What I Bring</h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }} className="skills-grid five-grid">
            <SkillGroup title="Programming" color="#BF5700" items={SKILLS_PROGRAMMING} />
            <SkillGroup title="CAD & Simulation" color="#7a4010" items={SKILLS_CAD} />
            <SkillGroup title="Web & Tools" color="#5c3d1e" items={SKILLS_WEB} />
            <SkillGroup title="Interpersonal" color="#3d2e1e" items={SKILLS_SOFT} />
            <SkillGroup title="Languages & Certifications" color="#1a1209" items={SKILLS_LANG} />
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" style={{ background: '#BF5700' }}>
        <div className="section-inner" style={{ maxWidth: 1200, margin: '0 auto', padding: '100px 24px', textAlign: 'center' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.6)', marginBottom: 16 }}>Let's Connect</p>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 56, fontWeight: 900, color: '#fff', letterSpacing: '-2px', marginBottom: 20 }}>
            Ready to Talk Product?
          </h2>
          <p style={{ fontSize: 18, color: 'rgba(255,255,255,0.75)', maxWidth: 520, margin: '0 auto 48px', lineHeight: 1.7 }}>
            I'm actively seeking Summer 2027 Product Management internships. Download my documents or connect with me on LinkedIn.
          </p>

          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 32 }}>
            <a
              href={resumePdf}
              download="Adrian_Raj_Cover_Letter.pdf"
              style={{ padding: '16px 32px', background: '#fff', color: '#BF5700', fontWeight: 700, fontSize: 15, textDecoration: 'none', borderRadius: 4, transition: 'opacity 0.2s', letterSpacing: '0.02em', display: 'inline-flex', alignItems: 'center', gap: 8 }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '0.9' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
            >
              ↓ Download Cover Letter
            </a>
            <a
              href={coverLetterPdf}
              download="Adrian_Raj_Resume.pdf"
              style={{ padding: '16px 32px', background: 'rgba(255,255,255,0.15)', color: '#fff', fontWeight: 700, fontSize: 15, textDecoration: 'none', borderRadius: 4, border: '1px solid rgba(255,255,255,0.35)', transition: 'background 0.2s', letterSpacing: '0.02em', display: 'inline-flex', alignItems: 'center', gap: 8 }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.25)' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.15)' }}
            >
              ↓ Download Resume
            </a>
            <a
              href="https://www.linkedin.com/in/adrianraj28"
              target="_blank"
              rel="noopener noreferrer"
              style={{ padding: '16px 32px', background: '#fff', color: '#BF5700', fontWeight: 700, fontSize: 15, textDecoration: 'none', borderRadius: 4, transition: 'opacity 0.2s', letterSpacing: '0.02em' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = '0.9' }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = '1' }}
            >
              LinkedIn ↗
            </a>
          </div>

          <p style={{ marginTop: 48, fontSize: 13, color: 'rgba(255,255,255,0.45)' }}>
            🤘 Hook 'Em · The University of Texas at Austin · Adrian Raj © 2026
          </p>
        </div>
      </section>
    </div>
  )
}

function ExperienceCard({ company, role, location, date, bullets, tag, color }: {
  company: string, role: string, location: string, date: string,
  bullets: string[], tag: string, color: string
}) {
  const [open, setOpen] = useState(false)

  return (
    <div style={{ borderRadius: 8, overflow: 'hidden', border: '1px solid #e8e0d4', transition: 'box-shadow 0.2s', boxShadow: open ? '0 4px 24px rgba(191,87,0,0.08)' : 'none' }}>
      <button
        onClick={() => setOpen(!open)}
        style={{ width: '100%', background: '#fff', border: 'none', cursor: 'pointer', padding: '24px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, textAlign: 'left' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 18, flex: 1 }}>
          <div style={{ width: 4, height: 44, background: color, borderRadius: 2, flexShrink: 0 }} />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4, flexWrap: 'wrap' }}>
              <span style={{ fontFamily: 'Playfair Display, serif', fontSize: 19, fontWeight: 800, color: '#1a1209' }}>{company}</span>
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color, background: color + '18', padding: '2px 8px', borderRadius: 3 }}>{tag}</span>
            </div>
            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 14, color: '#6b5c46', fontWeight: 500 }}>{role}</span>
              <span style={{ fontSize: 14, color: '#a89880' }}>{location} · {date}</span>
            </div>
          </div>
        </div>
        <span style={{ fontSize: 18, color, transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'none', flexShrink: 0 }}>▾</span>
      </button>
      {open && (
        <div style={{ background: '#faf8f4', padding: '0 28px 24px 28px', borderTop: '1px solid #f0ebe3' }}>
          <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10, paddingTop: 20 }}>
            {bullets.map((b, i) => (
              <li key={i} style={{ fontSize: 15, color: '#3d2e1e', display: 'flex', gap: 12, alignItems: 'flex-start', lineHeight: 1.6 }}>
                <span style={{ color, fontWeight: 700, marginTop: 2, flexShrink: 0 }}>→</span>
                {b}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

type Position = { role: string; date: string; bullets: string[] }

function ProgressionCard({ org, location, positions, bg }: {
  org: string; location: string; positions: Position[]; bg: string
}) {
  const [openIdx, setOpenIdx] = useState<number | null>(0)
  const multi = positions.length > 1

  return (
    <div style={{ background: bg, border: '1px solid #e8e0d4', borderRadius: 8, overflow: 'hidden', borderTop: '3px solid #BF5700' }}>
      <div style={{ padding: '22px 24px 16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
          <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: 17, fontWeight: 800, color: '#1a1209', lineHeight: 1.3, margin: 0 }}>{org}</h3>
          <span style={{ fontSize: 11, color: '#a89880', whiteSpace: 'nowrap', flexShrink: 0, paddingTop: 2 }}>{location}</span>
        </div>
        {multi && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 10 }}>
            <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: '#BF5700', background: 'rgba(191,87,0,0.1)', padding: '2px 8px', borderRadius: 3 }}>
              {positions.length} Roles · Career Progression
            </span>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {positions.map((pos, i) => {
          const isOpen = openIdx === i
          const isLatest = i === 0
          return (
            <div key={i} style={{ borderTop: '1px solid #f0ebe3' }}>
              {multi && (
                <div style={{ display: 'flex', alignItems: 'stretch', padding: '0 24px' }}>
                  {/* Timeline bar */}
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingRight: 14, paddingTop: 14 }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: isLatest ? '#BF5700' : '#d4c5b0', border: `2px solid ${isLatest ? '#BF5700' : '#c8b89a'}`, flexShrink: 0 }} />
                    {i < positions.length - 1 && (
                      <div style={{ width: 2, flex: 1, background: '#e0d4c4', minHeight: 24, marginTop: 4 }} />
                    )}
                  </div>
                  <div style={{ flex: 1 }}>
                    <button
                      onClick={() => setOpenIdx(isOpen ? null : i)}
                      style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '12px 0', textAlign: 'left', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}
                    >
                      <div>
                        <p style={{ fontSize: 13, fontWeight: 700, color: isLatest ? '#BF5700' : '#6b5c46', marginBottom: 2 }}>{pos.role}</p>
                        <p style={{ fontSize: 11, color: '#a89880' }}>{pos.date}</p>
                      </div>
                      <span style={{ fontSize: 14, color: '#BF5700', transition: 'transform 0.2s', transform: isOpen ? 'rotate(180deg)' : 'none', flexShrink: 0 }}>▾</span>
                    </button>
                    {isOpen && (
                      <ul style={{ padding: 0, margin: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 7, paddingBottom: 14 }}>
                        {pos.bullets.map((b, j) => (
                          <li key={j} style={{ fontSize: 13, color: '#5c4a35', lineHeight: 1.6, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                            <span style={{ color: '#BF5700', fontWeight: 700, flexShrink: 0, marginTop: 2 }}>·</span>
                            {b}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              )}
              {!multi && (
                <div style={{ padding: '14px 24px 20px' }}>
                  <p style={{ fontSize: 13, fontWeight: 600, color: '#BF5700', marginBottom: 4 }}>{pos.role}</p>
                  <p style={{ fontSize: 11, color: '#a89880', marginBottom: 12 }}>{pos.date}</p>
                  <ul style={{ padding: 0, margin: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 7 }}>
                    {pos.bullets.map((b, j) => (
                      <li key={j} style={{ fontSize: 13, color: '#5c4a35', lineHeight: 1.6, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                        <span style={{ color: '#BF5700', fontWeight: 700, flexShrink: 0, marginTop: 2 }}>·</span>
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function LeadershipCard(props: { org: string; location: string; positions: Position[] }) {
  return <ProgressionCard {...props} bg="#fff" />
}

function VolunteerCard(props: { org: string; location: string; positions: Position[] }) {
  return <ProgressionCard {...props} bg="#faf8f4" />
}

function LegislationCard({ number, title, assembly, summary, impact, pdf, filename }: {
  number: string, title: string, assembly: string, summary: string, impact: string, pdf: string, filename: string
}) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ background: '#fff', border: '1px solid #e8e0d4', borderLeft: '4px solid #BF5700', borderRadius: 8, overflow: 'hidden', transition: 'box-shadow 0.2s' }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = '0 6px 24px rgba(191,87,0,0.09)' }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = 'none' }}
    >
      <div style={{ padding: '24px 24px 0' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, marginBottom: 10 }}>
          <span style={{ fontFamily: 'Playfair Display, serif', fontSize: 22, fontWeight: 900, color: '#BF5700', flexShrink: 0 }}>{number}</span>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#6b5c46', background: '#f0ebe3', padding: '3px 8px', borderRadius: 3, marginTop: 4, whiteSpace: 'nowrap' }}>Passed</span>
        </div>
        <h4 style={{ fontFamily: 'Playfair Display, serif', fontSize: 15, fontWeight: 800, color: '#1a1209', lineHeight: 1.4, marginBottom: 6 }}>{title}</h4>
        <p style={{ fontSize: 11, color: '#a89880', marginBottom: 16 }}>{assembly}</p>
      </div>

      <button
        onClick={() => setOpen(!open)}
        style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '0 24px 16px', display: 'flex', alignItems: 'center', gap: 6, color: '#BF5700', fontSize: 12, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', textAlign: 'left' }}
      >
        <span style={{ transition: 'transform 0.2s', display: 'inline-block', transform: open ? 'rotate(90deg)' : 'none' }}>▶</span>
        {open ? 'Hide Summary' : 'Read Summary'}
      </button>

      {open && (
        <div style={{ padding: '0 24px 20px', borderTop: '1px solid #f0ebe3' }}>
          <p style={{ fontSize: 14, color: '#3d2e1e', lineHeight: 1.7, paddingTop: 16, marginBottom: 12 }}>{summary}</p>
          <div style={{ background: '#faf8f4', border: '1px solid #e8e0d4', borderRadius: 4, padding: '10px 14px' }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#BF5700', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 3 }}>Outcome</p>
            <p style={{ fontSize: 13, color: '#3d2e1e' }}>{impact}</p>
          </div>
        </div>
      )}

      <div style={{ padding: '12px 24px 20px' }}>
        <a
          href={pdf}
          download={filename}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 16px', background: '#BF5700', color: '#fff', fontSize: 12, fontWeight: 700, textDecoration: 'none', borderRadius: 4, letterSpacing: '0.04em', transition: 'background 0.2s' }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#a34a00' }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#BF5700' }}
        >
          ↓ Download Full Resolution
        </a>
      </div>
    </div>
  )
}

function SkillGroup({ title, color, items }: { title: string, color: string, items: string[] }) {
  return (
    <div style={{ background: '#fff', border: '1px solid #e8e0d4', borderRadius: 8, padding: '28px', borderTop: `3px solid ${color}` }}>
      <h3 style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color, marginBottom: 20 }}>{title}</h3>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
        {items.map(skill => (
          <span
            key={skill}
            style={{ fontSize: 13, fontWeight: 500, color: '#3d2e1e', background: '#faf8f4', border: '1px solid #e8e0d4', borderRadius: 4, padding: '6px 12px', transition: 'border-color 0.2s, color 0.2s', cursor: 'default' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = color; (e.currentTarget as HTMLElement).style.color = color }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = '#e8e0d4'; (e.currentTarget as HTMLElement).style.color = '#3d2e1e' }}
          >
            {skill}
          </span>
        ))}
      </div>
    </div>
  )
}
